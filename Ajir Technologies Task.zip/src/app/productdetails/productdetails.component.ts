import { Component, OnInit, Inject } from '@angular/core';
import {ActivatedRoute} from "@angular/router"

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  constructor(@Inject(ActivatedRoute) public ar) { }
productdetails;ratearr;halfstar=0
  ngOnInit() {
    // To print rating stars
    this.ar.params.subscribe(x=>{
      this.productdetails=x;
      var rating=x.prating
      this.ratearr=[]
      for(var i=1;i<=rating;i++){
          this.ratearr.push(i)
      }
      i--;
      if(rating>i){
        this.halfstar=1
      }
    })
  }

}
