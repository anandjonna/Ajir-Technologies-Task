import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router"
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
product
  constructor(private ar:ActivatedRoute, private products:ProductsService) {
    // To acess the products from service
    this.product=products.products
    }
obj
  ngOnInit(){ 
    // To recieve the parameters from the Url 
    this.ar.params.subscribe(x=>{
      this.obj=x;
     
    })
  }

}
