import { Injectable } from '@angular/core';

@Injectable()
export class ProductsService {

  constructor() { }
  // List of products
  products=[{pimage:"jeans.jpg",pname:"jeans",pprice:600,prating:4.5,pcat:1},
  {pimage:"jeans1.jpg",pname:"uspolo",pprice:500,prating:4,pcat:1},
  {pimage:"jeans2.jpg",pname:"Arrow",pprice:900,prating:3.5,pcat:1},
  {pimage:"jeans3.jpg",pname:"denims",pprice:800,prating:5,pcat:1},
  {pimage:"jeans4.jpg",pname:"blue jeans",pprice:700,prating:4.5,pcat:1},
  {pimage:"jeans5.jpg",pname:"american",pprice:400,prating:4,pcat:1},
  {pimage:"jeans6.jpg",pname:"woodland",pprice:450,prating:4.5,pcat:1},
  {pimage:"jeans7.jpg",pname:"sparx",pprice:699,prating:3.5,pcat:1},
  {pimage:"jeans8.jpg",pname:"foriegn",pprice:999,prating:4,pcat:1},
  {pimage:"tshirt.jpg",pname:"police",pprice:600,prating:4.5,pcat:2},
  {pimage:"tshirt1.jpg",pname:"Levis",pprice:500,prating:4,pcat:2},
  {pimage:"tshirt4.jpg",pname:"Adidas",pprice:900,prating:3.5,pcat:2},
  {pimage:"tshirt3.jpg",pname:"Diesel",pprice:800,prating:5,pcat:2},
  {pimage:"tshirt4.jpg",pname:"supreme",pprice:700,prating:4.5,pcat:2},
  {pimage:"tshirt5.jpg",pname:"Hollister",pprice:400,prating:4,pcat:2},
  {pimage:"tshirt6.jpg",pname:"champion",pprice:450,prating:4.5,pcat:2},
  {pimage:"jeans.jpg",pname:"lee",pprice:699,prating:3.5,pcat:2},
  {pimage:"jeans8.jpg",pname:"wrangler",pprice:999,prating:4,pcat:2},
  {pimage:"jeans.jpg",pname:"jeans",pprice:600,prating:4.5,pcat:1},
  {pimage:"jeans1.jpg",pname:"uspolo",pprice:500,prating:4,pcat:1}
 ]

}
