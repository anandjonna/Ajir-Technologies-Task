import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import {ActivatedRoute} from "@angular/router"

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {
  product;obj;key;
  constructor(private products:ProductsService,private ar:ActivatedRoute) {
    // To access the product details from the service
    this.product=this.products.products
 }
ratearr=[];halfstar=0;
filter:any={pname:""};
filter1:any={pprice:""};
filter2:any={prating:""};


// Running loop to print the products rating in the form of stars

funrating(rate){
  var rating=rate
 this.halfstar=0
         this.ratearr=[]
          for(var i=1;i<=rating;i++){
              this.ratearr.push(i)
          }
          i--;
         
          if(rating>i){
            
            this.halfstar=1
          }
}
  ngOnInit() {
    // To recieve the  parameters from the url
    this.ar.params.subscribe(x=>{
      this.obj=x;
    })
    
  }

}
