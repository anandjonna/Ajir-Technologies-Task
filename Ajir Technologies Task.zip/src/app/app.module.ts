import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from "@angular/router"
import {FormsModule} from "@angular/forms"
import {Ng2SearchPipeModule} from "ng2-search-filter"
import {OrderModule} from "ngx-order-pipe"
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import {ProductsService} from './products.service'
import {FilterPipeModule} from 'ngx-filter-pipe'

// Preparing routing for Single page Application
var rout=[{path:"",component:HomepageComponent},
          {path:"home",component:HomepageComponent},
          {path:"product",component:ProductpageComponent},
          {path:"productdetails",component:ProductdetailsComponent}
        ]
// converting Object into RouterModule object 
var obj=RouterModule.forRoot(rout)

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    ProductpageComponent,
    ProductdetailsComponent
  ],
  imports: [
    BrowserModule,obj,Ng2SearchPipeModule,FormsModule,OrderModule,FilterPipeModule
  ],
  providers: [ProductsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
